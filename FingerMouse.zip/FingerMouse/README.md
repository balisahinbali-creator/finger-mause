# FingerMouse
Ön kamera + MediaPipe Hand Landmarker ile el hareketiyle Android'i kontrol eder.
Derleme: GitHub Actions (.github/workflows/build.yml) -> Releases > latest > app-debug.apk
Hareketler: İşaret parmağı=imleç, Pinch=tık, Yumruk=basılı tut/sürükle, Rock (500 ms)=ana ekran.
