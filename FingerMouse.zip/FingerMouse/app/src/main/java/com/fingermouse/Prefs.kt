package com.fingermouse

import android.content.Context

enum class Key(val id: String, val def: Int, val min: Int, val max: Int) {
    SENS("sens", 180, 50, 300),     // /100 -> 0.5x..3.0x
    SMOOTH("smooth", 60, 0, 90),    // % yumusatma
    PINCH("pinch", 30, 10, 50),     // /100 -> pinch esigi (el boyuna oran)
    CLICK("click", 80, 0, 400),     // ms tiklama gecikmesi
    HOLD("hold", 150, 0, 500)       // ms yumruk basili tutma gecikmesi
}

class Prefs(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("fm", Context.MODE_PRIVATE)
    fun get(k: Key): Int = p.getInt(k.id, k.def)
    fun set(k: Key, v: Int) = p.edit().putInt(k.id, v).apply()
    val sensitivity: Float get() = get(Key.SENS) / 100f
    val smoothing: Float get() = get(Key.SMOOTH) / 100f
    val pinchThr: Float get() = get(Key.PINCH) / 100f
    val clickDelay: Long get() = get(Key.CLICK).toLong()
    val holdDelay: Long get() = get(Key.HOLD).toLong()
}
