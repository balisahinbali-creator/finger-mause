package com.fingermouse

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.Size
import android.view.Display
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

object TrackerBus {
    @Volatile var running = false
    @Volatile var previewListener: ((Bitmap, Boolean, String) -> Unit)? = null
    @Volatile var stateListener: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())
    fun notifyState() { main.post { stateListener?.invoke() } }
}

class TrackerService : LifecycleService(), GestureOutput {
    companion object {
        const val ACTION_STOP = "com.fingermouse.STOP"
        private const val CH = "fm_tracking"
        private const val NID = 1
        private const val TAG = "FingerMouse"
    }

    private var landmarker: HandLandmarker? = null
    private var executor: ExecutorService? = null
    private var provider: ProcessCameraProvider? = null
    private var analysis: ImageAnalysis? = null
    private lateinit var engine: GestureEngine
    private val main = Handler(Looper.getMainLooper())
    private var started = false
    private var lastTs = 0L
    private var lastPreview = 0L
    private var lastRotation = -1

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            if (started) shutdown() else stopSelf()
            return START_NOT_STICKY
        }
        if (!started) begin()
        return START_NOT_STICKY
    }

    private fun begin() {
        started = true
        engine = GestureEngine(Prefs(this), this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "El takibi", NotificationManager.IMPORTANCE_LOW))
        ServiceCompat.startForeground(this, NID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)

        val ex = Executors.newSingleThreadExecutor()
        executor = ex
        ex.execute {
            try {
                val opts = HandLandmarker.HandLandmarkerOptions.builder()
                    .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
                    .setRunningMode(RunningMode.VIDEO)
                    .setNumHands(1)
                    .setMinHandDetectionConfidence(0.5f)
                    .setMinHandPresenceConfidence(0.5f)
                    .setMinTrackingConfidence(0.5f)
                    .build()
                landmarker = HandLandmarker.createFromOptions(applicationContext, opts)
                main.post { bindCamera() }
            } catch (e: Exception) {
                Log.e(TAG, "model", e)
                main.post { fail("Model yüklenemedi: ${e.message}") }
            }
        }
    }

    private fun bindCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                val p = f.get(); provider = p
                val a = ImageAnalysis.Builder()
                    .setTargetResolution(Size(480, 360))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                a.setAnalyzer(executor!!, ImageAnalysis.Analyzer { analyze(it) })
                analysis = a
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, a)
                TrackerBus.running = true
                GestureAccessibilityService.instance?.setTracking(true)
                TrackerBus.notifyState()
            } catch (e: Exception) {
                Log.e(TAG, "camera", e)
                fail("Kamera açılamadı: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val lm = landmarker ?: return
            val rotNow = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).rotation
            if (rotNow != lastRotation) { lastRotation = rotNow; analysis?.targetRotation = rotNow }

            val raw = proxy.toBitmap()
            val rot = proxy.imageInfo.rotationDegrees
            val bmp = if (rot == 0) raw else
                Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, Matrix().apply { postRotate(rot.toFloat()) }, true)

            var ts = SystemClock.uptimeMillis()
            if (ts <= lastTs) ts = lastTs + 1
            lastTs = ts

            val res = lm.detectForVideo(BitmapImageBuilder(bmp).build(), ts)
            val hand = res.landmarks().firstOrNull()
            val g = if (hand != null && hand.size >= 21) {
                val xs = FloatArray(21) { hand[it].x() }
                val ys = FloatArray(21) { hand[it].y() }
                engine.process(xs, ys, bmp.width.toFloat() / bmp.height, ts)
            } else engine.noHand(ts)

            val pl = TrackerBus.previewListener
            if (pl != null && ts - lastPreview > 100) {
                lastPreview = ts
                val small = makePreview(bmp, hand)
                val has = hand != null
                main.post { pl(small, has, g.label) }
            }
            if (bmp !== raw) bmp.recycle()
            raw.recycle()
        } catch (e: Exception) {
            Log.e(TAG, "analyze", e)
        } finally {
            proxy.close()
        }
    }

    private fun makePreview(src: Bitmap, hand: List<NormalizedLandmark>?): Bitmap {
        val w = 240
        val h = (240f * src.height / src.width).toInt()
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.save()
        c.scale(-1f, 1f, w / 2f, h / 2f)   // ayna goruntusu
        c.drawBitmap(src, Rect(0, 0, src.width, src.height), Rect(0, 0, w, h), null)
        c.restore()
        if (hand != null) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GREEN }
            for (l in hand) c.drawCircle((1f - l.x()) * w, l.y() * h, 3f, p)
        }
        return out
    }

    // ---------- GestureOutput -> erisilebilirlik servisi ----------
    private val acc get() = GestureAccessibilityService.instance
    override fun cursor(x: Float, y: Float, mode: Int) { acc?.moveCursor(x, y, mode) }
    override fun tap(x: Float, y: Float) { acc?.tap(x, y) }
    override fun dragStart(x: Float, y: Float) { acc?.dragStart(x, y) }
    override fun dragMove(x: Float, y: Float) { acc?.dragMove(x, y) }
    override fun dragEnd(x: Float, y: Float) { acc?.dragEnd(x, y) }
    override fun home() { acc?.goHome() }
    override fun handLost() { acc?.hideCursor() }

    private fun notification(): Notification {
        val stop = PendingIntent.getService(this, 0,
            Intent(this, TrackerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val text = if (GestureAccessibilityService.instance == null)
            "Erişilebilirlik kapalı: imleç ve tıklama çalışmaz" else "Ön kamera el takibi için kullanılıyor"
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("FingerMouse çalışıyor")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Durdur", stop)
            .build()
    }

    private fun fail(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        shutdown()
    }

    private fun shutdown() {
        if (!started) return
        started = false
        TrackerBus.running = false
        if (::engine.isInitialized) engine.reset()
        runCatching { provider?.unbindAll() }
        GestureAccessibilityService.instance?.setTracking(false)
        val lm = landmarker; landmarker = null
        executor?.let { ex -> ex.execute { runCatching { lm?.close() } }; ex.shutdown() }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        TrackerBus.notifyState()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
