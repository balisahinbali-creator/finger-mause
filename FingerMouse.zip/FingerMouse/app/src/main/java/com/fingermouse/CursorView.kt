package com.fingermouse

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.view.View

class CursorView(c: Context) : View(c) {
    var mode = 0
        set(v) { if (field != v) { field = v; invalidate() } }
    private var flashUntil = 0L
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 6f }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)

    fun flash() {
        flashUntil = SystemClock.uptimeMillis() + 180
        invalidate()
        postInvalidateDelayed(200)
    }

    override fun onDraw(canvas: Canvas) {
        val flashing = SystemClock.uptimeMillis() < flashUntil
        val color = when {
            flashing -> 0xFF4CAF50.toInt()
            mode == 2 -> 0xFFE53935.toInt()
            mode == 1 -> 0xFF4CAF50.toInt()
            else -> 0xFF3B6EF5.toInt()
        }
        ring.color = color; dot.color = color
        val cx = width / 2f; val cy = height / 2f
        canvas.drawCircle(cx, cy, width / 2f - 6f, ring)
        canvas.drawCircle(cx, cy, if (flashing || mode == 2) 14f else 7f, dot)
    }
}
