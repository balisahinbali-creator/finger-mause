package com.fingermouse

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class GestureAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: GestureAccessibilityService? = null
        private const val SEG_MS = 40L
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var view: CursorView? = null
    private var size = 0
    private val dm = DisplayMetrics()

    private var stroke: GestureDescription.StrokeDescription? = null
    private var dragActive = false
    private var endReq = false
    private var inFlight = false
    private var lastX = 0f
    private var lastY = 0f
    @Volatile private var curX = 0f
    @Volatile private var curY = 0f

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        size = (48 * resources.displayMetrics.density).toInt()
        lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        view = CursorView(this).also { it.visibility = View.INVISIBLE; wm.addView(it, lp) }
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        return super.onUnbind(intent)
    }

    private fun toPx(nx: Float, ny: Float): Pair<Float, Float> {
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return Pair(nx * dm.widthPixels, ny * dm.heightPixels)
    }

    // ---------- Imlec ----------
    fun moveCursor(nx: Float, ny: Float, mode: Int) {
        val (x, y) = toPx(nx, ny)
        main.post {
            val v = view ?: return@post
            lp.x = (x - size / 2f).toInt(); lp.y = (y - size / 2f).toInt()
            v.mode = mode
            if (v.visibility != View.VISIBLE) v.visibility = View.VISIBLE
            runCatching { wm.updateViewLayout(v, lp) }
        }
    }

    fun hideCursor() { main.post { view?.visibility = View.INVISIBLE } }

    fun setTracking(on: Boolean) { if (!on) { hideCursor(); main.post { forceEndDrag() } } }

    // ---------- Tek tik ----------
    fun tap(nx: Float, ny: Float) {
        val (x, y) = toPx(nx, ny)
        main.post {
            if (dragActive) return@post
            val path = Path().apply { moveTo(x, y) }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 60)).build()
            dispatchGesture(g, null, null)
            view?.flash()
        }
    }

    // ---------- Basili tutma / surukleme (kesintisiz stroke) ----------
    fun dragStart(nx: Float, ny: Float) {
        val (x, y) = toPx(nx, ny)
        main.post {
            if (dragActive) return@post
            curX = x; curY = y; lastX = x; lastY = y
            dragActive = true; endReq = false; stroke = null; inFlight = false
            sendSegment()
        }
    }

    fun dragMove(nx: Float, ny: Float) {
        val (x, y) = toPx(nx, ny)
        curX = x; curY = y
    }

    fun dragEnd(nx: Float, ny: Float) {
        val (x, y) = toPx(nx, ny)
        main.post {
            if (!dragActive) return@post
            curX = x; curY = y; endReq = true
            if (!inFlight) sendSegment()
        }
    }

    private fun forceEndDrag() {
        if (dragActive) { endReq = true; if (!inFlight) sendSegment() }
    }

    private fun sendSegment() {
        if (!dragActive || inFlight) return
        val ex = curX; val ey = curY
        val last = endReq
        val path = Path().apply { moveTo(lastX, lastY); lineTo(ex, ey) }
        val prev = stroke
        val st = if (prev == null) GestureDescription.StrokeDescription(path, 0, SEG_MS, !last)
        else prev.continueStroke(path, 0, SEG_MS, !last)
        stroke = st
        lastX = ex; lastY = ey
        inFlight = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(st).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) {
                    inFlight = false
                    if (last) { dragActive = false; stroke = null } else sendSegment()
                }
                override fun onCancelled(g: GestureDescription?) {
                    inFlight = false; dragActive = false; stroke = null
                }
            }, null)
        if (!ok) { inFlight = false; dragActive = false; stroke = null }
    }

    // ---------- Ana ekran ----------
    fun goHome() { main.post { performGlobalAction(GLOBAL_ACTION_HOME) } }
}
