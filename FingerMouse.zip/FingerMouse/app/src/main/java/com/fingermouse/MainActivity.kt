package com.fingermouse

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.fingermouse.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: Prefs

    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        refresh()
        if (ok) onToggle() else Toast.makeText(this, "Kamera izni gerekli", Toast.LENGTH_LONG).show()
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { startTracking() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        prefs = Prefs(this)

        addSlider("İmleç hassasiyeti", Key.SENS) { "%.1fx".format(it / 100f) }
        addSlider("Hareket yumuşatma", Key.SMOOTH) { "$it%" }
        addSlider("Tıklama hassasiyeti (pinch eşiği)", Key.PINCH) { "%.2f".format(it / 100f) }
        addSlider("Tıklama gecikmesi", Key.CLICK) { "$it ms" }
        addSlider("Yumruk basılı tutma gecikmesi", Key.HOLD) { "$it ms" }

        b.btnToggle.setOnClickListener { onToggle() }
        b.btnCam.setOnClickListener { camPerm.launch(Manifest.permission.CAMERA) }
        b.btnAcc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    }

    override fun onStart() {
        super.onStart()
        TrackerBus.previewListener = { bmp, hand, label ->
            b.ivPreview.setImageBitmap(bmp)
            b.tvHint.text = ""
            b.tvHand.text = "El: " + if (hand) "algılandı ✓" else "algılanmadı"
            b.tvGesture.text = "Hareket: $label"
        }
        TrackerBus.stateListener = { refresh() }
        refresh()
    }

    override fun onStop() {
        TrackerBus.previewListener = null
        TrackerBus.stateListener = null
        super.onStop()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun hasCam() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    private fun hasNotif() = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun onToggle() {
        if (TrackerBus.running) {
            startService(Intent(this, TrackerService::class.java).setAction(TrackerService.ACTION_STOP))
            return
        }
        if (!hasCam()) { camPerm.launch(Manifest.permission.CAMERA); return }
        if (!hasNotif()) { notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS); return }
        startTracking()
    }

    private fun startTracking() {
        if (GestureAccessibilityService.instance == null)
            Toast.makeText(this, "Erişilebilirlik izni kapalı: imleç ve tıklama çalışmaz", Toast.LENGTH_LONG).show()
        ContextCompat.startForegroundService(this, Intent(this, TrackerService::class.java))
    }

    private fun refresh() {
        val run = TrackerBus.running
        b.btnToggle.text = if (run) "Kamerayı durdur" else "Kamerayı başlat"
        if (!run) {
            b.ivPreview.setImageDrawable(null)
            b.tvHint.text = "Kamera kapalı"
            b.tvHand.text = "El: -"
            b.tvGesture.text = "Hareket: -"
        }
        val cam = hasCam()
        b.tvCam.text = "Kamera izni: " + if (cam) "verildi ✓" else "gerekli ✗"
        b.btnCam.visibility = if (cam) android.view.View.GONE else android.view.View.VISIBLE
        val acc = GestureAccessibilityService.instance != null
        b.tvAcc.text = "Erişilebilirlik: " + if (acc) "etkin ✓" else "kapalı ✗ (Yüklü hizmetler > FingerMouse)"
        b.btnAcc.visibility = if (acc) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun addSlider(title: String, key: Key, fmt: (Int) -> String) {
        val d = resources.displayMetrics.density
        val label = TextView(this).apply { setPadding(0, (16 * d).toInt(), 0, 0) }
        val sb = SeekBar(this).apply { min = key.min; max = key.max; progress = prefs.get(key) }
        fun upd(v: Int) { label.text = "$title: ${fmt(v)}" }
        upd(sb.progress)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { upd(p); if (fromUser) prefs.set(key, p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val box: LinearLayout = b.llSliders
        box.addView(label); box.addView(sb)
    }
}
