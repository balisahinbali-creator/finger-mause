package com.fingermouse

import kotlin.math.abs
import kotlin.math.hypot

enum class Gesture(val label: String) {
    NONE("El algılanmadı"), OPEN("Açık el"), POINT("İşaret parmağı"),
    PINCH("Pinch (tıklama)"), FIST("Yumruk (basılı tutma)"), ROCK("Rock (ana ekran)")
}

interface GestureOutput {
    fun cursor(x: Float, y: Float, mode: Int)   // 0=normal 1=pinch 2=surukleme
    fun tap(x: Float, y: Float)
    fun dragStart(x: Float, y: Float)
    fun dragMove(x: Float, y: Float)
    fun dragEnd(x: Float, y: Float)
    fun home()
    fun handLost()
}

/** Tum koordinatlar 0..1 normalize ekran koordinatidir. */
class GestureEngine(private val s: Prefs, private val out: GestureOutput) {
    private companion object {
        const val ROCK_HOLD = 500L
        const val ROCK_RESET = 300L
        const val LOST = 250L
        const val REARM = 100L
        const val DEAD = 0.0015f
    }

    private class P(val t: Long, val x: Float, val y: Float)
    private val hist = ArrayDeque<P>()

    private var sx = 0f; private var sy = 0f
    private var spx = 0f; private var spy = 0f
    private var cx = 0.5f; private var cy = 0.5f
    private var wasFrozen = true
    private var havePalm = false

    private var dragging = false
    private var ax = 0f; private var ay = 0f
    private var palmX0 = 0f; private var palmY0 = 0f

    private var pinchHeld = false; private var pinchFired = false
    private var pinchSince = 0L; private var pinchOff = 0L
    private var fistSince = 0L; private var fistOff = 0L
    private var rockSince = 0L; private var nonRock = 0L; private var rockLatched = false
    private var lostSince = 0L; private var lostNotified = false

    private fun ema(prev: Float, v: Float, a: Float) = if (abs(v - prev) < DEAD) prev else prev + a * (v - prev)

    private fun cursorAt(t: Long): P? {
        var best = hist.firstOrNull()
        for (p in hist) { if (p.t <= t) best = p else break }
        return best
    }

    fun process(x: FloatArray, y: FloatArray, aspect: Float, now: Long): Gesture {
        lostSince = 0L; lostNotified = false
        fun d(a: Int, b: Int) = hypot((x[a] - x[b]) * aspect, y[a] - y[b])
        val palm = maxOf(d(0, 9), 1e-4f)
        fun r(tip: Int, mcp: Int) = d(tip, 0) / maxOf(d(mcp, 0), 1e-4f)
        val rI = r(8, 5); val rM = r(12, 9); val rR = r(16, 13); val rP = r(20, 17)
        val thr = s.pinchThr

        val rock = rI > 1.5f && rP > 1.5f && rM < 1.35f && rR < 1.35f
        val pinchNear = d(4, 8) / palm < (if (pinchHeld) thr * 1.4f else thr) && rI > 1.15f
        val fistThr = if (dragging) 1.45f else 1.25f
        val fist = maxOf(rI, rM, rR, rP) < fistThr

        val raw = when {
            !dragging && rock -> Gesture.ROCK
            !dragging && pinchNear -> Gesture.PINCH
            fist -> Gesture.FIST
            rI > 1.5f && rM > 1.5f && rR > 1.5f -> Gesture.OPEN
            else -> Gesture.POINT
        }

        // ---- ROCK: en az 500 ms, sonra notr donusu bekle
        if (raw == Gesture.ROCK) {
            nonRock = 0L
            if (rockSince == 0L) rockSince = now
            if (!rockLatched && now - rockSince >= ROCK_HOLD) { rockLatched = true; out.home() }
        } else {
            rockSince = 0L
            if (nonRock == 0L) nonRock = now
            if (rockLatched && now - nonRock >= ROCK_RESET) rockLatched = false
        }

        // ---- PINCH: esik + gecikme, parmaklar ayrilmadan ikinci tik yok
        if (raw == Gesture.PINCH) {
            pinchOff = 0L; pinchHeld = true
            if (pinchSince == 0L) pinchSince = now
        } else {
            if (pinchOff == 0L) pinchOff = now
            if (now - pinchOff >= REARM) { pinchHeld = false; pinchFired = false; pinchSince = 0L }
        }

        // ---- Imlec dondurma (pinch / yumruk / rock sirasinda parmak ucu titremesin)
        val frozen = raw == Gesture.PINCH || pinchHeld || raw == Gesture.ROCK || raw == Gesture.FIST || dragging
        if (frozen && !wasFrozen && !dragging) {
            cursorAt(now - 150)?.let { cx = it.x; cy = it.y }
        }

        val g = s.sensitivity
        val a = 1f - s.smoothing
        val mx = (0.5f + ((1f - x[8]) - 0.5f) * g).coerceIn(0f, 1f)
        val my = (0.5f + (y[8] - 0.5f) * g).coerceIn(0f, 1f)
        val mpx = 0.5f + ((1f - x[9]) - 0.5f) * g
        val mpy = 0.5f + (y[9] - 0.5f) * g
        if (!havePalm) { spx = mpx; spy = mpy; havePalm = true } else { spx = ema(spx, mpx, a); spy = ema(spy, mpy, a) }

        if (!frozen) {
            if (wasFrozen) { sx = mx; sy = my } else { sx = ema(sx, mx, a); sy = ema(sy, my, a) }
            cx = sx; cy = sy
            hist.addLast(P(now, cx, cy))
            while (hist.size > 1 && now - hist.first().t > 500) hist.removeFirst()
        }
        wasFrozen = frozen

        // ---- PINCH tik
        if (raw == Gesture.PINCH && !pinchFired && !dragging && now - pinchSince >= s.clickDelay) {
            pinchFired = true
            out.tap(cx, cy)
        }

        // ---- FIST: basili tutma / surukleme
        if (raw == Gesture.FIST) {
            fistOff = 0L
            if (fistSince == 0L) fistSince = now
            if (!dragging && !pinchHeld && now - fistSince >= s.holdDelay) {
                dragging = true
                ax = cx; ay = cy; palmX0 = spx; palmY0 = spy
                out.dragStart(cx, cy)
            }
        } else {
            fistSince = 0L
            if (dragging) {
                if (fistOff == 0L) fistOff = now
                if (now - fistOff >= maxOf(s.holdDelay, 100L)) {
                    dragging = false; fistOff = 0L
                    out.dragEnd(cx, cy)
                }
            }
        }

        if (dragging) {
            cx = (ax + (spx - palmX0)).coerceIn(0f, 1f)
            cy = (ay + (spy - palmY0)).coerceIn(0f, 1f)
            out.dragMove(cx, cy)
        }
        out.cursor(cx, cy, if (dragging) 2 else if (pinchHeld) 1 else 0)
        return raw
    }

    fun noHand(now: Long): Gesture {
        if (lostSince == 0L) lostSince = now
        if (now - lostSince >= LOST) {
            reset()
            if (!lostNotified) { lostNotified = true; out.handLost() }
        }
        return Gesture.NONE
    }

    /** Takip durdugunda / el kaybolunca tum durumu sifirlar; son hareket tekrar tetiklenmez. */
    fun reset() {
        if (dragging) { dragging = false; out.dragEnd(cx, cy) }
        havePalm = false; wasFrozen = true
        pinchHeld = false; pinchFired = false; pinchSince = 0L; pinchOff = 0L
        fistSince = 0L; fistOff = 0L
        rockSince = 0L; nonRock = 0L; rockLatched = false
        hist.clear()
    }
}
